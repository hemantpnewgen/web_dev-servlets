package assignment_4;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletConfig;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.tomcat.util.http.Cookies;

/**
 * Servlet implementation class myserv
 */
@WebServlet("/cookie_servlet")
public class cookie_servlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public cookie_servlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see Servlet#init(ServletConfig)
	 */
	public void init(ServletConfig config) throws ServletException {
		// TODO Auto-generated method stub
	}

	/**
	 * @see Servlet#destroy()
	 */
	public void destroy() {
		// TODO Auto-generated method stub
	}

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		response.setContentType("text/html");
		PrintWriter out = response.getWriter();
		
		out.println("<h2> Email : </h2> <h4>" + request.getParameter("email") + "</h4>");
		out.println("<h2> Password : </h2><h4>" + request.getParameter("password") + "</h4>");
		
		out.println("<p> Cookie Values: </p>");
		Cookie sav_email = new Cookie("sav_email", request.getParameter("email"));
		Cookie sav_password = new Cookie("sav_password", request.getParameter("password"));
		
		sav_email.setMaxAge(10);
		sav_password.setMaxAge(10);
		
		response.addCookie(sav_email);
		response.addCookie(sav_password);
		
		Cookie[] cookies =null;
		cookies= request.getCookies();
		
		if(null != cookies && cookies.length>0){
			for(int i=0; i< cookies.length;i++){
				System.out.println("Cookie Name :" + cookies[i].getName() + " , Cookie Value : " + cookies[i].getValue());
			}
		}
}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
	}

}

