package assignment_3;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.Date;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

/**
 * Servlet implementation class track_session
 */
@WebServlet("/track_session")
public class track_session extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public track_session() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws IOException, ServletException {
		HttpSession session = request.getSession(true);
		Date thisTime = new Date(session.getCreationTime());
		Date lastTime = 
		                new Date(session.getLastAccessedTime());

		String title = "Welcome Back";
			response.setContentType("text/html");
			PrintWriter out = response.getWriter();

			String docType =
			"<!doctype html public \"-//w3c//dtd html 4.0 " +
			"transitional//en\">\n";
			out.println(docType +
			        "<html>\n" +
			        "<head><title>" + title + "</title></head>\n" +
			        "<h1 align=\"center\">" + title + "</h1>\n" +
			         "<h2 align=\"center\">Session Infomation</h2>\n" +
			        " align=\"center\">\n" +
			        "  <th>Session info</th><th>value</th></tr>\n" +
			        "<tr>\n" +
			        "  <td>id</td>\n" +
			        "  <td>" + session.getId() + "</td></tr>\n" +
			        "<tr>\n" +
			        "  <td>Current Time: </td>\n" +
			        "  <td>" + thisTime + 
			        "  </td></tr>\n" +
			        "<tr>\n" +
			        "  <td>Last Accessed: </td>\n" +
			        "  <td>" + lastTime + 
			        "</tr>\n" +
			        "</table>\n" +
			        "</body></html>");

		response.getWriter().append("Served at: ").append(request.getContextPath());
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}

